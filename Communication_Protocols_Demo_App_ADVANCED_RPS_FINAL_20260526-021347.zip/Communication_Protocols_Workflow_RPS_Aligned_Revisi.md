# Communication Protocols Workflow - RPS Aligned Revision

Sumber utama: `Sem2_Communication Protocol_SainsData_RPS_HaikalShiddiq.docx`

Catatan koreksi:

- REST API CRUD berada pada Pertemuan 2 sebagai bagian dari HTTP/HTTPS dan RESTful API dasar.
- Workflow Pertemuan 3-16 dimulai dari WebSocket, bukan REST CRUD.
- Praktikum setelah UTS harus memasukkan Postman, Newman/Postman CLI, Wireshark, MQTT, n8n, repository, dan project evidence sesuai RPS.

## Mapping Revisi Pertemuan 3-16

| Pertemuan | Topik RPS | Sub-CPMK/CPMK | Fokus praktikum | Tools utama | Demo app page |
|---|---|---|---|---|---|
| 3 | WebSocket & Real-Time Communication | Sub-CPMK2, Sub-CPMK3; CPMK-1, CPMK-2 | Persistent connection, send/receive event, compare REST polling vs WebSocket | Browser UI, Postman WebSocket, Wireshark optional | P3 WebSocket |
| 4 | MQTT dan Protokol IoT untuk telemetry | Sub-CPMK2, Sub-CPMK3; CPMK-1, CPMK-2 | Publish/subscribe, topic, telemetry payload, broker concept | Demo MQTT simulator, Postman, MQTTX/HiveMQ optional | P4 MQTT IoT |
| 5 | gRPC dan Protocol Buffers | Sub-CPMK3; CPMK-2 | `.proto` schema, service contract, request/response message, gRPC mock | Demo app, Python gRPC optional, grpcurl optional | P5 gRPC Protobuf |
| 6 | Data Encoding: JSON, XML, Protobuf | Sub-CPMK3, Sub-CPMK4; CPMK-2 | Compare serialization format, parse data, explain schema | Demo app, Postman, Python optional | P6 JSON/XML/Protobuf |
| 7 | TLS/SSL dan HTTP/TLS fundamentals; review UTS | Sub-CPMK4, Sub-CPMK5; CPMK-2, CPMK-3 | Status code, slow API, TLS/security concept, Wireshark prep | Demo app, curl, Wireshark, openssl | P7 TLS/Troubleshooting |
| 8 | UTS | Sub-CPMK1-5; CPMK-1, CPMK-2, CPMK-3 | Protocol evidence, API test result, capture, short report | Postman, curl, Wireshark, repo | P8 UTS Evidence |
| 9 | API Design & Documentation menggunakan Postman | Sub-CPMK4, Sub-CPMK5; CPMK-2, CPMK-3 | Collection quality, environment, tests, documentation, Newman runner concept | Postman, Newman/Postman CLI, demo app | P9 API Docs/Newman |
| 10 | Rate Limiting dan Load Balancing | Sub-CPMK5; CPMK-3 | 429 response, retry-after, backend distribution, reliability | Demo app, Postman, Wireshark optional | P10 Reliability |
| 11 | Microservices Communication Patterns | Sub-CPMK6, Sub-CPMK7; CPMK-3 | Service chain, gateway, internal service call, failure point | Demo app, Postman, diagram tool | P11 Microservices |
| 12 | Monitoring & Logging Protocol | Sub-CPMK6, Sub-CPMK7, Sub-CPMK8; CPMK-3 | Logs, metrics, traces, telemetry, observability evidence | Demo app, Postman, Wireshark optional | P12 Observability |
| 13 | Proyek Protokol Fase 1 | Sub-CPMK7-8, Sub-CPMK9; CPMK-3, CPMK-4 | Architecture draft, automation flow, protocol choice | n8n, Postman, GitHub, demo app | P13-15 n8n Project |
| 14 | Proyek Protokol Fase 2 | Sub-CPMK9, Sub-CPMK10; CPMK-4 | Build workflow, improve docs, integrate evidence | n8n, Postman, GitHub, Wireshark optional | P13-15 n8n Project |
| 15 | Presentasi Proyek & Peer Review | Sub-CPMK9, Sub-CPMK10; CPMK-4 | Demo checkpoint, peer review, final readiness | GitHub, PPT, demo app, n8n | P13-15 n8n Project |
| 16 | UAS Final Project Presentation | Sub-CPMK6-10; CPMK-3, CPMK-4 | Final demo, report, repository, Q&A, reflection | GitHub, Postman, n8n, Wireshark, PPT | P16 UAS |

## Praktikum Interaktif Utama

### Pertemuan 3 - WebSocket

Endpoint:

```text
ws://localhost:8088/ws/echo
```

Mahasiswa:

1. Connect ke WebSocket endpoint.
2. Kirim JSON event.
3. Amati echo response.
4. Screenshot connected state dan message log.
5. Jelaskan perbedaan WebSocket dengan REST polling.

Referensi detail: `communication-protocols-demo-app/LAB_PERTEMUAN_3_4_REVISI.md`

### Pertemuan 4 - MQTT Telemetry

Endpoint simulator:

```text
POST /api/mqtt/publish
GET /api/mqtt/messages?topic=class/commproto/sensor-01/temperature
```

Mahasiswa:

1. Publish telemetry payload.
2. Load messages by topic.
3. Bandingkan topic sensor-01 dan sensor-02.
4. Jelaskan publisher, subscriber, topic, broker concept.

Referensi detail: `communication-protocols-demo-app/LAB_PERTEMUAN_3_4_REVISI.md`

## Praktikum Setelah UTS

Rujukan detail:

```text
communication-protocols-demo-app/LAB_POST_UTS_N8N_AUTOMATION.md
communication-protocols-demo-app/LAB_ADVANCED_INTERACTIVE_P3_P16.md
```

Ringkasan aktivitas:

| Pertemuan | Praktikum |
|---|---|
| 9 | Import Postman collection, inspect OpenAPI-style spec, add tests, run collection runner/Newman fallback. |
| 10 | Trigger rate limit sampai 429, observe load-balanced backend rotation. |
| 11 | Simulate microservices order flow dan buat sequence diagram. |
| 12 | Generate traffic, inspect metrics/logs/trace. |
| 13 | Buat n8n workflow: Webhook Trigger -> Set/Edit Fields -> HTTP Request -> Respond to Webhook. |
| 14 | Integrasikan workflow dengan project mini, rapikan documentation dan evidence. |
| 15 | Presentasi checkpoint dan peer review. |
| 16 | Final presentation dengan PDF, PPT, GitHub repo, Postman collection, n8n evidence, logs/metrics/trace. |

## Tools Inline dengan RPS

| Tool | Dipakai pada | Catatan |
|---|---|---|
| Wireshark | P7, P8, P10, P12, UAS optional | Evidence packet/protocol/troubleshooting. |
| Postman | P2 recap, P4-P16 | API testing, collection, docs, tests. |
| cURL | P7, P8, P9 optional | CLI reproduction. |
| MQTT client/broker simulator | P4, P12, UAS | Demo app simulator untuk konsep; MQTTX/HiveMQ/Mosquitto untuk MQTT asli. |
| Newman/Postman CLI | P9-P10 | Runner automation; fallback Postman Collection Runner. |
| n8n | P13-P15, UAS | Workflow automation and integration evidence. |
| GitHub/repository | P8, P13-P16 | Evidence, source, documentation. |

## Deliverables Revisi

| Fase | Deliverables |
|---|---|
| P3-P4 | WebSocket evidence, MQTT telemetry evidence, reflection protocol comparison. |
| P5-P7 | `.proto`/schema explanation, JSON/XML/Protobuf comparison, TLS/troubleshooting notes. |
| UTS | Report, PPT, Postman collection, traffic capture/screenshot, repo evidence. |
| P9-P12 | Postman/Newman evidence, reliability test evidence, microservices diagram, observability logs/metrics/trace. |
| P13-P16 | n8n workflow screenshot, project repo, report, PPT, final demo, reflection. |
