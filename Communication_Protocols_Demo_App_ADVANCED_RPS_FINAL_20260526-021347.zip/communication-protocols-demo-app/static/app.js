const jsonHeaders = { "Content-Type": "application/json" };
let ws = null;

const wsTemplates = {
  dashboard_refresh: {
    event: "dashboard_refresh",
    dashboard: "sales-ops",
    value: 1,
    changedMetric: "orders_per_minute"
  },
  order_created: {
    event: "order_created",
    orderId: "ORD-2026-001",
    amount: 450000,
    priority: "normal"
  },
  sensor_alert: {
    event: "sensor_alert",
    deviceId: "sensor-01",
    temperature: 38.4,
    severity: "warning"
  },
  chat_message: {
    event: "chat_message",
    user: "student-01",
    message: "Realtime message from WebSocket lab"
  }
};

function pretty(value) {
  if (typeof value === "string") return value;
  return JSON.stringify(value, null, 2);
}

function byId(id) {
  return document.getElementById(id);
}

function on(id, event, handler) {
  const element = byId(id);
  if (element) element.addEventListener(event, handler);
}

function setOutput(id, value) {
  const element = byId(id);
  if (element) element.textContent = value;
}

function readJson(id) {
  const raw = byId(id).value;
  try {
    return JSON.parse(raw);
  } catch (error) {
    throw new Error(`Invalid JSON in ${id}: ${error.message}`);
  }
}

async function request(method, path, body) {
  const options = { method, headers: {} };
  if (body !== undefined) {
    options.headers = jsonHeaders;
    options.body = typeof body === "string" ? body : JSON.stringify(body);
  }
  const response = await fetch(path, options);
  const text = await response.text();
  let parsed = text;
  try { parsed = JSON.stringify(JSON.parse(text), null, 2); } catch (_) {}
  return `${method} ${path}\nHTTP ${response.status} ${response.statusText}\n\n${parsed || "(no response body)"}`;
}

async function run(outputId, fn) {
  try {
    setOutput(outputId, await fn());
  } catch (error) {
    setOutput(outputId, `Request failed: ${error.message}`);
  }
}

function setPage(page) {
  document.querySelectorAll(".nav").forEach(btn => btn.classList.toggle("active", btn.dataset.page === page));
  document.querySelectorAll(".page").forEach(section => section.classList.toggle("active", section.id === `page-${page}`));
}

document.querySelectorAll(".nav").forEach(btn => btn.addEventListener("click", () => setPage(btn.dataset.page)));

async function checkHealth() {
  try {
    const response = await fetch("/api/health");
    byId("serverStatus").textContent = response.ok ? "Server OK" : "Server issue";
  } catch (_) {
    byId("serverStatus").textContent = "Server offline";
  }
}

async function loadProducts() {
  const response = await fetch("/api/products");
  const payload = await response.json();
  byId("productsTable").innerHTML = payload.data.map(product => `
    <tr>
      <td>${product.id}</td>
      <td>${product.name}</td>
      <td>${product.category}</td>
      <td>${product.price}</td>
      <td>${product.stock}</td>
    </tr>
  `).join("");
}

on("restMethod", "change", event => {
  const method = event.target.value;
  const path = byId("restPath");
  if (method === "GET") path.value = "/api/products";
  if (method === "POST") path.value = "/api/products";
  if (["PUT", "PATCH", "DELETE"].includes(method)) path.value = "/api/products/1";
});

on("sendRest", "click", async () => {
  const method = byId("restMethod").value;
  const path = byId("restPath").value;
  const body = byId("restBody").value;
  await run("restResponse", async () => {
    const result = await request(method, path, ["GET", "DELETE"].includes(method) ? undefined : body);
    await loadProducts();
    return result;
  });
});

on("resetProducts", "click", async () => {
  await run("restResponse", async () => {
    const result = await request("POST", "/api/reset", {});
    await loadProducts();
    return result;
  });
});

document.querySelectorAll("[data-fetch]").forEach(btn => {
  btn.addEventListener("click", async () => {
    const page = btn.closest(".page").id.replace("page-", "");
    const outputId = `${page}Output`;
    await run(outputId, () => request("GET", btn.dataset.fetch));
  });
});

on("sendWebhook", "click", async () => {
  const body = { source: "postman-demo", event: "order.created", orderId: "ORD-2026-001", amount: 450000 };
  await run("utsOutput", () => request("POST", "/api/webhook/inbox", body));
});

on("submitUtsEvidence", "click", async () => {
  const body = {
    studentId: "NIM-DEMO",
    case: "UTS API + packet capture evidence",
    methods: ["GET", "POST"],
    evidence: ["postman-screenshot", "curl-command", "pcapng-optional"]
  };
  await run("utsOutput", () => request("POST", "/api/uts/evidence", body));
});

on("wsTemplate", "change", event => {
  byId("wsMessage").value = pretty(wsTemplates[event.target.value]);
});

on("connectWs", "click", () => {
  const log = byId("wsLog");
  const channel = encodeURIComponent(byId("wsChannel").value);
  if (ws && ws.readyState === WebSocket.OPEN) ws.close();
  ws = new WebSocket(`ws://${location.host}/ws/echo?channel=${channel}`);
  ws.onopen = () => { log.textContent = `Connected to ws://${location.host}/ws/echo?channel=${channel}`; };
  ws.onmessage = event => { log.textContent += `\nRECV ${event.data}`; };
  ws.onclose = () => { log.textContent += "\nClosed."; };
  ws.onerror = () => { log.textContent += "\nWebSocket error."; };
});

on("sendWs", "click", () => {
  const log = byId("wsLog");
  if (!ws || ws.readyState !== WebSocket.OPEN) {
    log.textContent += "\nNot connected.";
    return;
  }
  const message = byId("wsMessage").value;
  ws.send(message);
  log.textContent += `\nSEND ${message}`;
});

on("postRealtimeEvent", "click", async () => {
  await run("wsLog", async () => {
    const payload = readJson("wsMessage");
    const body = {
      channel: byId("wsChannel").value,
      event: payload.event || byId("wsTemplate").value,
      payload,
      transport: "http-post-event"
    };
    return request("POST", "/api/realtime/events", body);
  });
});

on("loadRealtimeEvents", "click", async () => {
  const channel = encodeURIComponent(byId("wsChannel").value);
  await run("wsLog", () => request("GET", `/api/realtime/events?channel=${channel}`));
});

on("closeWs", "click", () => {
  if (ws) ws.close();
});

on("publishMqtt", "click", async () => {
  await run("mqttOutput", () => {
    const body = {
      clientId: byId("mqttClientId").value,
      topic: byId("mqttTopic").value,
      qos: Number(byId("mqttQos").value),
      retained: byId("mqttRetained").checked,
      payload: readJson("mqttPayload")
    };
    return request("POST", "/api/mqtt/publish", body);
  });
});

on("loadMqtt", "click", async () => {
  const topic = encodeURIComponent(byId("mqttTopic").value);
  await run("mqttOutput", () => request("GET", `/api/mqtt/messages?topic=${topic}`));
});

on("loadMqttByFilter", "click", async () => {
  const topicFilter = encodeURIComponent(byId("mqttFilter").value);
  await run("mqttOutput", () => request("GET", `/api/mqtt/messages?filter=${topicFilter}`));
});

on("loadMqttTopics", "click", async () => {
  await run("mqttOutput", () => request("GET", "/api/mqtt/topics"));
});

on("clearMqtt", "click", async () => {
  await run("mqttOutput", () => request("POST", "/api/mqtt/clear", {}));
});

on("runGrpcMock", "click", async () => {
  await run("grpcOutput", () => request("POST", "/api/grpc/infer", readJson("grpcBody")));
});

on("runGrpcCall", "click", async () => {
  await run("grpcOutput", () => {
    const body = { method: byId("grpcMethod").value, payload: readJson("grpcBody") };
    return request("POST", "/api/grpc/call", body);
  });
});

on("convertEncoding", "click", async () => {
  await run("encodingOutput", () => {
    const body = { to: byId("encodingTarget").value, records: readJson("encodingRecords") };
    return request("POST", "/api/encoding/convert", body);
  });
});

on("runTroubleTest", "click", async () => {
  await run("troubleCustomOutput", () => {
    const body = {
      status: Number(byId("troubleStatus").value),
      delayMs: Number(byId("troubleDelay").value),
      scenario: byId("troubleScenario").value
    };
    return request("POST", "/api/troubleshooting/test", body);
  });
});

on("simulatePostmanRun", "click", async () => {
  await run("api-docsOutput", () => {
    const body = {
      folder: byId("postmanFolder").value,
      iterations: Number(byId("postmanIterations").value)
    };
    return request("POST", "/api/postman/run", body);
  });
});

on("resetReliability", "click", async () => {
  await run("reliabilityOutput", () => request("POST", "/api/reliability/reset", {}));
});

on("simulateLoad", "click", async () => {
  await run("reliabilityOutput", () => request("POST", "/api/reliability/simulate-load", { requests: 9 }));
});

on("runMicroserviceOrder", "click", async () => {
  await run("casesOutput", () => {
    const failAt = byId("microFailAt").value;
    const body = { orderId: "ORD-DEMO-001", amount: 450000 };
    if (failAt) body.failAt = failAt;
    return request("POST", "/api/microservices/orders", body);
  });
});

on("runCustomLog", "click", async () => {
  const body = {
    event: "custom.observability.event",
    severity: "info",
    service: "demo-frontend",
    message: "Mahasiswa membuat log event dari UI",
    traceId: "demo-trace-001"
  };
  await run("observabilityOutput", () => request("POST", "/api/observability/custom-log", body));
});

on("sendAutomationEvent", "click", async () => {
  const body = {
    protocol: "MQTT+REST+n8n",
    event: "telemetry.workflow.completed",
    deviceId: "sensor-01",
    evidence: "n8n-workflow-run"
  };
  await run("automationOutput", () => request("POST", "/api/automation/inbox", body));
});

on("simulateWorkflowRun", "click", async () => {
  const body = {
    workflow: "telemetry-to-inbox",
    event: "telemetry.workflow.completed",
    triggerPayload: {
      deviceId: "sensor-01",
      temperature: 31.2,
      source: "mqtt-simulator"
    }
  };
  await run("automationOutput", () => request("POST", "/api/automation/workflow-run", body));
});

on("createProjectEvent", "click", async () => {
  const body = { protocol: "MQTT+WebSocket+n8n", event: "uas.demo.executed", evidence: "screenshot+postman+automation-log" };
  await run("projectOutput", () => request("POST", "/api/project/events", body));
});

checkHealth();
loadProducts();
