# Advanced Interactive Lab P3-P16

Dokumen ini adalah revisi detail agar praktikum P3 ke atas tidak berhenti di `GET` sederhana. Setiap pertemuan punya kombinasi `GET` untuk membaca state dan `POST` untuk membuat event, payload, workflow, failure scenario, atau evidence baru.

App lokal:

```text
http://localhost:8088
```

Postman collection:

```text
postman/Communication_Protocols_Demo_App.postman_collection.json
```

Variable Postman:

```text
base_url = http://localhost:8088
```

## Prinsip Demo Dosen

1. Dosen mulai dari halaman app sesuai pertemuan.
2. Dosen ubah input seperti `channel`, `topic`, `payload`, `RPC method`, `status code`, atau `failure point`.
3. Dosen jalankan `POST` untuk membuat state baru.
4. Dosen jalankan `GET` untuk membuktikan state berubah.
5. Mahasiswa screenshot request, response, dan interpretasi protocol.
6. Jika perlu evidence formal, ulangi request yang sama dari Postman collection.

## P3 - WebSocket and Real-Time Communication

Mapping RPS: WebSocket & Real-Time Communication.

Fokus konsep:

- Persistent connection.
- Event-driven message.
- Channel-based realtime update.
- Perbandingan WebSocket vs HTTP polling.

UI demo:

- Page: `P3 WebSocket`.
- Input yang bisa diubah mahasiswa:
  - `Channel`: `dashboard`, `orders`, `telemetry`, `alerts`.
  - `Event Template`: `dashboard_refresh`, `order_created`, `sensor_alert`, `chat_message`.
  - `Message JSON`: bebas selama valid JSON.

Demo 1: WebSocket asli dari browser.

1. Pilih `channel = dashboard`.
2. Pilih template `dashboard_refresh`.
3. Klik `Connect`.
4. Klik `Send Message`.
5. Ubah payload:

```json
{
  "event": "order_created",
  "orderId": "ORD-2026-009",
  "amount": 900000
}
```

6. Klik `Send Message` lagi.
7. Bahas perbedaan `SEND` dan `RECV`.

Demo 2: HTTP event API untuk evidence Postman.

```http
POST /api/realtime/events
GET /api/realtime/events?channel=dashboard
```

Sample body:

```json
{
  "channel": "alerts",
  "event": "sensor_alert",
  "transport": "http-post-event",
  "payload": {
    "deviceId": "sensor-02",
    "temperature": 39.4,
    "severity": "warning"
  }
}
```

Expected output:

- `POST` return `201`.
- `GET` return list event sesuai channel.

Evidence mahasiswa:

- Screenshot WebSocket connected state.
- Screenshot `SEND` dan `RECV`.
- Screenshot Postman `POST /api/realtime/events`.
- Screenshot Postman `GET /api/realtime/events?channel=...`.
- Reflection: kapan WebSocket lebih cocok daripada REST polling.

Fallback:

- Jika WebSocket client Postman bermasalah, pakai browser UI.
- Jika WebSocket blocked jaringan kantor, pakai HTTP event API sebagai simulasi event.

## P4 - MQTT and IoT Telemetry

Mapping RPS: MQTT dan Protokol IoT untuk telemetry.

Fokus konsep:

- Publisher, subscriber, broker concept.
- Topic hierarchy.
- Topic filter `+`.
- QoS concept.
- Retained message concept.
- Telemetry payload untuk data science.

UI demo:

- Page: `P4 MQTT IoT`.
- Input yang bisa diubah mahasiswa:
  - `Client ID`.
  - `Topic`.
  - `QoS`.
  - `Retained message`.
  - `Payload JSON`.
  - `Subscribe Filter`.

Demo utama:

1. Isi `Client ID`: `student-client-01`.
2. Isi topic:

```text
class/commproto/sensor-01/temperature
```

3. Isi payload:

```json
{
  "deviceId": "sensor-01",
  "temperature": 27.5,
  "humidity": 61
}
```

4. Pilih `QoS 1`.
5. Centang `Retained message`.
6. Klik `Publish`.
7. Klik `Load Messages`.
8. Ubah topic menjadi:

```text
class/commproto/sensor-02/humidity
```

9. Ubah payload:

```json
{
  "deviceId": "sensor-02",
  "humidity": 72,
  "battery": 88
}
```

10. Klik `Publish`.
11. Ubah filter:

```text
class/commproto/+/temperature
```

12. Klik `Load by Filter`.
13. Klik `Load Topics`.

Postman endpoints:

```http
POST /api/mqtt/publish
GET /api/mqtt/messages?topic=class/commproto/sensor-01/temperature
GET /api/mqtt/messages?filter=class/commproto/+/temperature
GET /api/mqtt/topics
POST /api/mqtt/clear
```

Expected output:

- `POST` return `201` dengan `clientId`, `topic`, `qos`, `retained`, `payload`.
- `GET topic` return message exact topic.
- `GET filter` return message yang match wildcard.
- `GET topics` return topic unik dan retained messages.

Evidence mahasiswa:

- Screenshot publish telemetry.
- Screenshot subscribe by exact topic.
- Screenshot subscribe by filter.
- Interpretasi topic hierarchy dan QoS.

Fallback:

- Jika ingin MQTT asli: pakai MQTTX/HiveMQ/Mosquitto.
- Jika broker publik bermasalah: tetap pakai simulator lokal ini.

## P5 - gRPC and Protocol Buffers

Mapping RPS: gRPC dan Protocol Buffers.

Fokus konsep:

- Service contract.
- `.proto` schema.
- RPC method.
- Request message vs response message.
- Perbandingan gRPC dengan REST.

UI demo:

- Page: `P5 gRPC Protobuf`.
- Input:
  - `RPC Method`: `Predict`, `BatchPredict`, `HealthCheck`.
  - `Message JSON`: payload request.

Endpoints:

```http
GET /api/grpc/proto
GET /api/grpc/services
POST /api/grpc/infer
POST /api/grpc/call
```

Sample `Predict`:

```json
{
  "method": "Predict",
  "payload": {
    "customerId": "C-1024",
    "features": {
      "avgOrderValue": 250000,
      "monthlyOrders": 7
    }
  }
}
```

Sample `BatchPredict`:

```json
{
  "method": "BatchPredict",
  "payload": {
    "items": [
      {"customerId": "C-1001", "features": {"monthlyOrders": 3}},
      {"customerId": "C-1002", "features": {"monthlyOrders": 9}}
    ]
  }
}
```

Expected output:

- `GET /api/grpc/proto` menampilkan schema.
- `GET /api/grpc/services` menampilkan service dan method.
- `POST /api/grpc/call` return response berbeda berdasarkan method.

Evidence:

- Screenshot `.proto`.
- Screenshot `Predict` dan `BatchPredict`.
- Analisis: field apa yang menjadi contract.

Fallback:

- Jika belum siap gRPC asli, gunakan mock ini untuk konsep.
- Advanced lab tetap bisa menggunakan Python `grpcio` dan `grpcurl`.

## P6 - Data Encoding JSON, XML, CSV, Protobuf

Mapping RPS: Data Encoding.

Fokus konsep:

- Serialization format.
- Human-readable vs schema-based format.
- Payload size.
- Format pilihan untuk data pipeline.

Endpoints:

```http
GET /api/exchange/json
GET /api/exchange/xml
GET /api/exchange/csv
GET /api/exchange/protobuf-schema
POST /api/encoding/convert
```

Sample body:

```json
{
  "to": "protobuf",
  "records": [
    {"id": 1, "sensor": "temperature", "value": 27.5, "unit": "celsius"}
  ]
}
```

Variasi tugas mahasiswa:

- Convert ke `json`.
- Convert ke `xml`.
- Convert ke `csv`.
- Convert ke `protobuf`.
- Bandingkan `byteLength`.

Evidence:

- Screenshot empat format.
- Catatan format paling mudah dibaca dan paling cocok untuk service-to-service.

## P7 - TLS/HTTP Troubleshooting and UTS Prep

Mapping RPS: TLS/SSL, HTTP/TLS fundamentals, troubleshooting.

Fokus konsep:

- Status code.
- Latency/delay.
- Error scenario.
- Header dan response body.
- Wireshark/curl evidence.

Endpoints:

```http
GET /api/health
GET /api/troubleshooting/status/400
GET /api/troubleshooting/status/404
GET /api/troubleshooting/slow?ms=1200
POST /api/troubleshooting/test
```

Sample `POST`:

```json
{
  "status": 429,
  "delayMs": 300,
  "scenario": "Client receives rate limit while testing API integration"
}
```

Expected output:

- Status sesuai input.
- Response menjelaskan scenario.
- Mahasiswa harus menghubungkan symptom, probable cause, dan next action.

Evidence:

- Screenshot Postman status code.
- Screenshot curl command.
- Optional Wireshark capture `tcp.port == 8088`.

## P8 - UTS Evidence

Mapping RPS: UTS.

Fokus:

- Individual evidence.
- API testing.
- Packet capture optional.
- Basic troubleshooting.

Endpoints:

```http
GET /api/uts/orders
POST /api/webhook/inbox
POST /api/uts/evidence
GET /api/webhook/inbox
```

Sample evidence body:

```json
{
  "studentId": "NIM-DEMO",
  "case": "UTS API + packet capture evidence",
  "methods": ["GET", "POST"],
  "evidence": ["postman-screenshot", "curl-command", "pcapng-optional"]
}
```

Minimum evidence:

- Postman collection screenshot.
- Response body screenshot.
- CLI/curl command.
- Short explanation of request and response.

## P9 - API Documentation and Newman/Postman Runner

Mapping RPS: API Design & Documentation using Postman.

Endpoints:

```http
GET /api/openapi
GET /api/postman-run-summary
POST /api/postman/run
```

Sample body:

```json
{
  "folder": "P9 API Documentation and Newman",
  "iterations": 2
}
```

Aktivitas:

1. Import collection.
2. Cek variable `base_url`.
3. Jalankan folder P9.
4. Tambahkan test minimal: status code expected.
5. Export screenshot runner.

Fallback:

- Jika Newman belum tersedia, gunakan Postman Collection Runner.

## P10 - Rate Limiting and Load Balancing

Mapping RPS: Rate Limiting dan Load Balancing.

Endpoints:

```http
GET /api/reliability/rate-limited
GET /api/reliability/load-balanced
POST /api/reliability/simulate-load
POST /api/reliability/reset
```

Sample `POST`:

```json
{
  "requests": 9
}
```

Aktivitas:

- Klik rate-limited API empat kali untuk memicu `429`.
- Jalankan simulate load untuk melihat backend `api-node-a/b/c`.
- Jelaskan mengapa client perlu retry/backoff.

Evidence:

- Screenshot response `429`.
- Screenshot load-balanced backend distribution.

## P11 - Microservices Communication Patterns

Mapping RPS: Microservices Communication Patterns.

Endpoints:

```http
GET /api/cases/protocol-decision
GET /api/microservices/order-flow
POST /api/microservices/orders
```

Sample success:

```json
{
  "orderId": "ORD-DEMO-001",
  "amount": 450000
}
```

Sample failure:

```json
{
  "orderId": "ORD-DEMO-002",
  "amount": 750000,
  "failAt": "payment-service"
}
```

Aktivitas:

- Jalankan flow sukses.
- Jalankan flow gagal pada `inventory-service`, `payment-service`, atau `notification-service`.
- Buat sequence diagram sederhana.
- Jelaskan protocol pada tiap hop.

Evidence:

- Screenshot traceId.
- Screenshot service yang gagal.
- Reflection: di mana perlu timeout, retry, atau compensation.

## P12 - Monitoring, Logging, Telemetry, Observability

Mapping RPS: Monitoring & Logging Protocol.

Endpoints:

```http
GET /api/observability/metrics
GET /api/observability/logs
GET /api/observability/trace/demo-trace-001
POST /api/observability/custom-log
```

Sample log:

```json
{
  "event": "custom.observability.event",
  "severity": "info",
  "service": "demo-postman",
  "message": "Mahasiswa membuat custom log dari Postman",
  "traceId": "demo-trace-001"
}
```

Aktivitas:

- Jalankan beberapa endpoint P9-P11.
- Buka metrics.
- Buka logs.
- Buka trace.
- Buat custom log.
- Bandingkan fungsi logs, metrics, dan traces.

Evidence:

- Screenshot metrics dengan request count.
- Screenshot logs.
- Screenshot trace.

## P13-P15 - n8n Automation and Project Phase

Mapping RPS: Proyek Protokol Fase 1, Fase 2, Project Presentation & Peer Review.

Endpoints:

```http
GET /api/automation/n8n-workflow-spec
POST /api/automation/inbox
POST /api/automation/workflow-run
GET /api/automation/inbox
```

Sample automation body:

```json
{
  "protocol": "MQTT+REST+n8n",
  "event": "telemetry.workflow.completed",
  "deviceId": "sensor-01",
  "evidence": "n8n-workflow-run"
}
```

Sample workflow simulation:

```json
{
  "workflow": "telemetry-to-inbox",
  "event": "telemetry.workflow.completed",
  "triggerPayload": {
    "deviceId": "sensor-01",
    "temperature": 31.2,
    "source": "mqtt-simulator"
  }
}
```

Aktivitas n8n:

1. Buat `Webhook Trigger`.
2. Tambah `Set/Edit Fields`.
3. Tambah `HTTP Request`.
4. POST ke:

```text
http://localhost:8088/api/automation/inbox
```

5. Jika n8n berjalan di Docker, gunakan:

```text
http://host.docker.internal:8088/api/automation/inbox
```

6. Tambah `Respond to Webhook`.
7. Screenshot workflow dan execution result.

Fallback:

- Jika n8n belum siap, gunakan `POST /api/automation/workflow-run` dari UI/Postman untuk simulasi workflow.

## P16 - UAS Final Project

Mapping RPS: UAS Final Project Presentation.

Endpoints:

```http
GET /api/project/summary
POST /api/project/events
GET /api/project/events
```

Sample body:

```json
{
  "protocol": "MQTT+WebSocket+n8n",
  "event": "uas.demo.executed",
  "evidence": "screenshot+postman+automation-log"
}
```

Minimum UAS evidence:

- GitHub repository.
- Source code or workflow export.
- Postman collection evidence.
- Screenshot protocol flow.
- Screenshot observability or automation evidence.
- Reflection: protocol used, reason, failure encountered, troubleshooting action.

## Rubrik Ringkas untuk P3-P16

| Komponen | Bobot | Indikator |
|---|---:|---|
| Protocol understanding | 25% | Bisa menjelaskan request/response, event, topic, method, schema, atau trace sesuai pertemuan. |
| Lab execution | 25% | Berhasil menjalankan `GET` dan `POST` dengan input yang dimodifikasi sendiri. |
| Evidence quality | 20% | Screenshot/log/response jelas dan bisa diverifikasi. |
| Troubleshooting analysis | 15% | Bisa menghubungkan status code, delay, failure point, atau missing payload dengan penyebab teknis. |
| Documentation | 10% | Catatan ringkas, rapi, dan menyebut endpoint serta payload. |
| Professionalism | 5% | Repo/filename/presentasi rapi, tidak hardcode bukti palsu. |
