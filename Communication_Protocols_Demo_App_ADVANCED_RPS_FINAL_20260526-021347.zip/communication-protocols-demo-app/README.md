# Communication Protocols Demo App

Satu aplikasi lokal untuk mendemokan materi Communication Protocols sesuai RPS yang dikirim.

Tujuan app ini bukan mengganti semua tool lab seperti Wireshark, Postman, MQTTX, atau grpcurl. Tujuannya adalah memberi dosen satu local backend dan UI browser yang stabil untuk demonstrasi kelas.

## Cara Menjalankan

Windows:

```powershell
cd "C:\Users\Yenny-Haikal\OneDrive\Documents\New project\communication-protocols-demo-app"
py server.py
```

macOS/Linux:

```bash
cd communication-protocols-demo-app
python3 server.py
```

Buka:

```text
http://localhost:8088
```

## Modul Pertemuan

| Pertemuan | Halaman demo | Endpoint utama |
|---|---|---|
| 2 Recap | HTTP/HTTPS & REST API CRUD prerequisite | `/api/products`, `/api/products/{id}` |
| 3 | WebSocket & Real-Time Communication | `ws://localhost:8088/ws/echo?channel=...`, `/api/realtime/events` |
| 4 | MQTT & IoT Telemetry Simulator | `/api/mqtt/publish`, `/api/mqtt/messages?topic=...`, `/api/mqtt/messages?filter=...`, `/api/mqtt/topics` |
| 5 | gRPC/Protobuf Concept Mock | `/api/grpc/proto`, `/api/grpc/services`, `/api/grpc/infer`, `/api/grpc/call` |
| 6 | JSON/XML/Protobuf/Data Encoding | `/api/exchange/json`, `/api/exchange/xml`, `/api/exchange/protobuf-schema`, `/api/encoding/convert` |
| 7 | TLS/HTTP Troubleshooting & UTS Prep | `/api/health`, `/api/troubleshooting/status/{code}`, `/api/troubleshooting/slow?ms=1000`, `/api/troubleshooting/test` |
| 8 | UTS Case Evidence | `/api/uts/orders`, `/api/webhook/inbox`, `/api/uts/evidence` |
| 9 | API Design & Documentation using Postman/Newman | `/api/openapi`, `/api/postman-run-summary`, `/api/postman/run` |
| 10 | Rate Limiting & Load Balancing | `/api/reliability/rate-limited`, `/api/reliability/load-balanced`, `/api/reliability/simulate-load` |
| 11 | Microservices Communication Patterns | `/api/microservices/order-flow`, `/api/microservices/orders` |
| 12 | Monitoring, Logging, Telemetry & Observability | `/api/observability/metrics`, `/api/observability/logs`, `/api/observability/trace/{id}`, `/api/observability/custom-log` |
| 13-15 | n8n Automation, Project Phase & Peer Review | `/api/automation/n8n-workflow-spec`, `/api/automation/inbox`, `/api/automation/workflow-run` |
| 16 | UAS Final Project Presentation | `/api/project/events`, `/api/project/summary` |

## Postman

Import collection:

```text
postman/Communication_Protocols_Demo_App.postman_collection.json
```

Variable default:

```text
base_url = http://localhost:8088
```

## Revisi Lab Pertemuan 3-4

Panduan praktikum interaktif yang sudah mengikuti revisi:

```text
LAB_PERTEMUAN_3_4_REVISI.md
```

## Revisi Advanced P3-P16

Panduan detail untuk demo yang lebih komprehensif, termasuk pilihan `GET`/`POST`, topic/channel/message berbeda, failure scenario, runner simulation, observability, dan n8n workflow:

```text
LAB_ADVANCED_INTERACTIVE_P3_P16.md
```

## Lab Post-UTS dan n8n Automation

Panduan praktikum setelah UTS yang diselaraskan dengan RPS:

```text
LAB_POST_UTS_N8N_AUTOMATION.md
```

## Catatan Teknis

- App ini dependency-free, hanya menggunakan Python standard library.
- WebSocket echo diimplementasikan minimal untuk text frames agar bisa demo Pertemuan 3.
- MQTT page adalah simulator pub/sub berbasis HTTP endpoint untuk Pertemuan 4, bukan MQTT broker asli. Untuk MQTT asli, gunakan HiveMQ/MQTTX/Mosquitto.
- gRPC page adalah mock konsep service contract, bukan gRPC HTTP/2 server asli. Untuk gRPC asli, gunakan lab Python `grpcio` dan `grpcurl`.
- REST API CRUD disediakan sebagai halaman recap Pertemuan 2/prerequisite, bukan materi utama Pertemuan 3-16.
- n8n automation membutuhkan instalasi n8n terpisah. Jika n8n berjalan di Docker, gunakan `host.docker.internal:8088` untuk mengakses app ini dari container.
