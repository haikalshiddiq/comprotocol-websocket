from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs
import base64
import hashlib
import json
import shutil
import struct
import threading
import time


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
STATIC = ROOT / "static"
PRODUCTS = DATA / "products.json"
PRODUCTS_SEED = DATA / "products.seed.json"
MESSAGES = DATA / "messages.json"
WEBHOOK_INBOX = DATA / "webhook_inbox.json"
AUTOMATION_INBOX = DATA / "automation_inbox.json"
REALTIME_EVENTS = DATA / "realtime_events.json"
HOST = "127.0.0.1"
PORT = 8088
LOCK = threading.Lock()
WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
REQUEST_LOGS = []
RATE_HITS = {}
BACKENDS = ["api-node-a", "api-node-b", "api-node-c"]
BACKEND_INDEX = 0


def now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def read_json(path):
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_json(path, payload):
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def next_id(items):
    return max([item.get("id", 0) for item in items], default=0) + 1


def mqtt_topic_match(topic_filter, topic):
    filter_parts = topic_filter.split("/")
    topic_parts = topic.split("/")
    for index, part in enumerate(filter_parts):
        if part == "#":
            return True
        if index >= len(topic_parts):
            return False
        if part != "+" and part != topic_parts[index]:
            return False
    return len(filter_parts) == len(topic_parts)


def content_type(path):
    suffix = path.suffix.lower()
    if suffix == ".css":
        return "text/css; charset=utf-8"
    if suffix == ".js":
        return "application/javascript; charset=utf-8"
    if suffix == ".html":
        return "text/html; charset=utf-8"
    return "application/octet-stream"


def record_request(method, path, status, response_type):
    entry = {
        "time": now_iso(),
        "method": method,
        "path": path,
        "status": status,
        "responseType": response_type,
    }
    with LOCK:
        REQUEST_LOGS.append(entry)
        del REQUEST_LOGS[:-80]


def rate_limited_response(client):
    now = time.time()
    window_seconds = 10
    limit = 3
    with LOCK:
        hits = [ts for ts in RATE_HITS.get(client, []) if now - ts <= window_seconds]
        if len(hits) >= limit:
            RATE_HITS[client] = hits
            return 429, {
                "error": "Too Many Requests",
                "limit": limit,
                "windowSeconds": window_seconds,
                "retryAfterSeconds": max(1, int(window_seconds - (now - hits[0]))),
                "teachingPoint": "Rate limiting protects API reliability by rejecting excessive requests.",
            }
        hits.append(now)
        RATE_HITS[client] = hits
        return 200, {
            "message": "Request accepted",
            "remaining": limit - len(hits),
            "limit": limit,
            "windowSeconds": window_seconds,
        }


def load_balanced_response():
    global BACKEND_INDEX
    with LOCK:
        backend = BACKENDS[BACKEND_INDEX % len(BACKENDS)]
        BACKEND_INDEX += 1
    return {
        "backend": backend,
        "latencyMs": 80 + (BACKENDS.index(backend) * 35),
        "teachingPoint": "Repeated requests are distributed across backend nodes.",
    }


class DemoHandler(BaseHTTPRequestHandler):
    server_version = "CommProtocolsDemo/1.0"

    def log_message(self, fmt, *args):
        print("%s - %s" % (self.address_string(), fmt % args))

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def _json(self, status, payload, headers=None):
        body = json.dumps(payload, indent=2).encode("utf-8")
        record_request(self.command, self.path, status, "json")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self._cors()
        if headers:
            for key, value in headers.items():
                self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def _text(self, status, payload, mime="text/plain; charset=utf-8"):
        body = payload.encode("utf-8")
        record_request(self.command, self.path, status, mime)
        self.send_response(status)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(body)))
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    def _no_content(self):
        record_request(self.command, self.path, 204, "no-content")
        self.send_response(204)
        self._cors()
        self.end_headers()

    def _body_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length == 0:
            return {}
        raw = self.rfile.read(length).decode("utf-8")
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            self._json(400, {"error": "Invalid JSON body", "raw": raw})
            return None

    def _product_id(self, path):
        parts = path.strip("/").split("/")
        if len(parts) == 3 and parts[:2] == ["api", "products"]:
            try:
                return int(parts[2])
            except ValueError:
                return None
        return None

    def _serve_file(self, file_path):
        if not file_path.exists() or not file_path.is_file():
            self._json(404, {"error": "File not found"})
            return
        body = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type(file_path))
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_HEAD(self):
        self.send_response(200)
        self._cors()
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)

        if self.headers.get("Upgrade", "").lower() == "websocket" and path == "/ws/echo":
            self._websocket_echo()
            return

        if path == "/":
            self._serve_file(ROOT / "index.html")
            return

        if path.startswith("/static/"):
            safe = path.replace("/static/", "", 1).replace("\\", "/")
            if ".." in safe:
                self._json(400, {"error": "Invalid static path"})
                return
            self._serve_file(STATIC / safe)
            return

        if path == "/api/health":
            self._json(200, {"status": "ok", "service": "Communication Protocols Demo App", "time": now_iso()})
            return

        if path == "/api/realtime/events":
            channel = query.get("channel", [None])[0]
            events = read_json(REALTIME_EVENTS)
            if channel:
                events = [event for event in events if event.get("channel") == channel]
            self._json(200, {"count": len(events), "channel": channel, "events": events[-30:]})
            return

        if path == "/api/openapi":
            self._json(200, _openapi_spec())
            return

        if path == "/api/postman-run-summary":
            self._json(200, _postman_run_summary())
            return

        if path == "/api/products":
            self._json(200, {"count": len(read_json(PRODUCTS)), "data": read_json(PRODUCTS)})
            return

        product_id = self._product_id(path)
        if product_id is not None:
            product = next((item for item in read_json(PRODUCTS) if item["id"] == product_id), None)
            if not product:
                self._json(404, {"error": "Product not found", "id": product_id})
                return
            self._json(200, product)
            return

        if path == "/api/exchange/json":
            self._json(200, {"format": "json", "records": _sample_records()})
            return

        if path == "/api/exchange/xml":
            records = "".join(
                f"<record><id>{r['id']}</id><sensor>{r['sensor']}</sensor><value>{r['value']}</value><unit>{r['unit']}</unit></record>"
                for r in _sample_records()
            )
            self._text(200, f'<?xml version="1.0" encoding="UTF-8"?><telemetry>{records}</telemetry>', "application/xml; charset=utf-8")
            return

        if path == "/api/exchange/csv":
            lines = ["id,sensor,value,unit"]
            lines.extend([f"{r['id']},{r['sensor']},{r['value']},{r['unit']}" for r in _sample_records()])
            self._text(200, "\n".join(lines) + "\n", "text/csv; charset=utf-8")
            return

        if path == "/api/exchange/protobuf-schema":
            self._text(200, _telemetry_proto_schema(), "text/plain; charset=utf-8")
            return

        if path.startswith("/api/troubleshooting/status/"):
            try:
                status = int(path.rsplit("/", 1)[-1])
            except ValueError:
                status = 400
            self._json(status, {"requestedStatus": status, "message": "Intentional troubleshooting response"})
            return

        if path == "/api/troubleshooting/slow":
            ms = min(int(query.get("ms", ["1000"])[0]), 5000)
            time.sleep(ms / 1000)
            self._json(200, {"message": "Slow response completed", "delayMs": ms})
            return

        if path == "/api/uts/orders":
            self._json(200, {"case": "UTS API evidence", "orders": _orders()})
            return

        if path == "/api/webhook/inbox":
            self._json(200, {"count": len(read_json(WEBHOOK_INBOX)), "data": read_json(WEBHOOK_INBOX)})
            return

        if path == "/api/mqtt/messages":
            topic = query.get("topic", [None])[0]
            topic_filter = query.get("filter", [None])[0]
            if topic_filter:
                topic_filter = topic_filter.replace(" ", "+")
            messages = read_json(MESSAGES)
            if topic:
                messages = [msg for msg in messages if msg["topic"] == topic]
            if topic_filter:
                messages = [msg for msg in messages if mqtt_topic_match(topic_filter, msg["topic"])]
            self._json(200, {"count": len(messages), "topic": topic, "filter": topic_filter, "messages": messages[-50:]})
            return

        if path == "/api/mqtt/topics":
            messages = read_json(MESSAGES)
            topics = sorted(set(msg["topic"] for msg in messages))
            retained = [msg for msg in messages if msg.get("retained")]
            self._json(200, {"topics": topics, "retainedMessages": retained[-20:]})
            return

        if path == "/api/reliability/rate-limited":
            status, payload = rate_limited_response(self.client_address[0])
            self._json(status, payload)
            return

        if path == "/api/reliability/load-balanced":
            self._json(200, load_balanced_response())
            return

        if path == "/api/microservices/order-flow":
            self._json(200, _microservice_order_flow())
            return

        if path == "/api/observability/metrics":
            self._json(200, _metrics())
            return

        if path == "/api/observability/logs":
            self._json(200, {"count": len(REQUEST_LOGS), "logs": REQUEST_LOGS[-30:]})
            return

        if path.startswith("/api/observability/trace/"):
            trace_id = path.rsplit("/", 1)[-1]
            self._json(200, _trace(trace_id))
            return

        if path == "/api/automation/n8n-workflow-spec":
            self._json(200, _n8n_workflow_spec())
            return

        if path == "/api/automation/inbox":
            self._json(200, {"count": len(read_json(AUTOMATION_INBOX)), "data": read_json(AUTOMATION_INBOX)})
            return

        if path == "/api/cases/protocol-decision":
            self._json(200, _protocol_case())
            return

        if path == "/api/grpc/proto":
            self._text(200, _proto_contract(), "text/plain; charset=utf-8")
            return

        if path == "/api/grpc/services":
            self._json(200, _grpc_services())
            return

        if path == "/api/project/events":
            self._json(200, {"events": read_json(MESSAGES)[-10:]})
            return

        if path == "/api/project/summary":
            self._json(200, _project_summary())
            return

        self._json(404, {"error": "Route not found", "path": path})

    def do_POST(self):
        path = urlparse(self.path).path

        if path == "/api/reset":
            with LOCK:
                shutil.copyfile(PRODUCTS_SEED, PRODUCTS)
                write_json(MESSAGES, [])
                write_json(WEBHOOK_INBOX, [])
                write_json(AUTOMATION_INBOX, [])
                write_json(REALTIME_EVENTS, [])
                REQUEST_LOGS.clear()
                RATE_HITS.clear()
            self._json(200, {"message": "All demo data reset"})
            return

        if path == "/api/products":
            body = self._body_json()
            if body is None:
                return
            missing = [field for field in ["name", "category", "price", "stock"] if field not in body]
            if missing:
                self._json(400, {"error": "Missing required fields", "missing": missing})
                return
            with LOCK:
                products = read_json(PRODUCTS)
                product = {
                    "id": next_id(products),
                    "name": body["name"],
                    "category": body["category"],
                    "price": body["price"],
                    "stock": body["stock"],
                    "createdAt": now_iso(),
                }
                products.append(product)
                write_json(PRODUCTS, products)
            self._json(201, product, headers={"Location": f"/api/products/{product['id']}"})
            return

        if path == "/api/realtime/events":
            body = self._body_json()
            if body is None:
                return
            event = {
                "id": int(time.time() * 1000),
                "channel": body.get("channel", "dashboard"),
                "event": body.get("event", "message.created"),
                "payload": body.get("payload", {}),
                "publishedAt": now_iso(),
                "transport": body.get("transport", "websocket-concept"),
            }
            with LOCK:
                events = read_json(REALTIME_EVENTS)
                events.append(event)
                write_json(REALTIME_EVENTS, events)
            self._json(201, event)
            return

        if path == "/api/webhook/inbox":
            body = self._body_json()
            if body is None:
                return
            event = {"id": int(time.time() * 1000), "receivedAt": now_iso(), "payload": body}
            with LOCK:
                inbox = read_json(WEBHOOK_INBOX)
                inbox.append(event)
                write_json(WEBHOOK_INBOX, inbox)
            self._json(201, event)
            return

        if path == "/api/mqtt/publish":
            body = self._body_json()
            if body is None:
                return
            if "topic" not in body or "payload" not in body:
                self._json(400, {"error": "topic and payload are required"})
                return
            message = {
                "id": int(time.time() * 1000),
                "clientId": body.get("clientId", "student-client"),
                "topic": body["topic"],
                "qos": body.get("qos", 0),
                "retained": bool(body.get("retained", False)),
                "payload": body["payload"],
                "publishedAt": now_iso(),
            }
            with LOCK:
                messages = read_json(MESSAGES)
                messages.append(message)
                write_json(MESSAGES, messages)
            self._json(201, message)
            return

        if path == "/api/mqtt/clear":
            with LOCK:
                write_json(MESSAGES, [])
            self._json(200, {"message": "MQTT simulator messages cleared"})
            return

        if path == "/api/reliability/reset":
            with LOCK:
                RATE_HITS.clear()
            self._json(200, {"message": "Reliability demo state reset"})
            return

        if path == "/api/microservices/orders":
            body = self._body_json()
            if body is None:
                return
            flow = _microservice_order_flow(body)
            self._json(201, flow)
            return

        if path == "/api/grpc/infer":
            body = self._body_json()
            if body is None:
                return
            features = body.get("features", {})
            score = 0.0
            score += min(float(features.get("avgOrderValue", 0)) / 500000, 1.0) * 0.55
            score += min(float(features.get("monthlyOrders", 0)) / 10, 1.0) * 0.45
            self._json(200, {
                "mock": True,
                "note": "This is a REST mock of a gRPC/Protobuf concept, not a real HTTP/2 gRPC server.",
                "requestMessage": "PredictionRequest",
                "responseMessage": "PredictionReply",
                "customerId": body.get("customerId"),
                "score": round(score, 3),
                "label": "high_value" if score >= 0.6 else "standard",
            })
            return

        if path == "/api/grpc/call":
            body = self._body_json()
            if body is None:
                return
            self._json(200, _grpc_call(body))
            return

        if path == "/api/encoding/convert":
            body = self._body_json()
            if body is None:
                return
            self._json(200, _encoding_convert(body))
            return

        if path == "/api/troubleshooting/test":
            body = self._body_json()
            if body is None:
                return
            status = int(body.get("status", 200))
            delay_ms = min(int(body.get("delayMs", 0)), 5000)
            if delay_ms:
                time.sleep(delay_ms / 1000)
            self._json(status, {
                "requestedStatus": status,
                "delayMs": delay_ms,
                "scenario": body.get("scenario", "custom troubleshooting test"),
                "headersToInspect": ["Content-Type", "Content-Length", "Status Code"],
                "teachingPoint": "Students should connect symptom, status code, delay, and probable cause.",
            })
            return

        if path == "/api/observability/custom-log":
            body = self._body_json()
            if body is None:
                return
            event = {
                "id": int(time.time() * 1000),
                "receivedAt": now_iso(),
                "event": body.get("event", "custom.observability.event"),
                "severity": body.get("severity", "info"),
                "service": body.get("service", "demo-service"),
                "message": body.get("message", "Custom log event from lab UI"),
                "traceId": body.get("traceId", "demo-trace-001"),
                "teachingPoint": "A log captures one event; compare it with metrics and traces for the same scenario.",
            }
            self._json(201, event)
            return

        if path == "/api/uts/evidence":
            body = self._body_json()
            if body is None:
                return
            evidence = {"id": int(time.time() * 1000), "submittedAt": now_iso(), "payload": body}
            with LOCK:
                inbox = read_json(WEBHOOK_INBOX)
                inbox.append(evidence)
                write_json(WEBHOOK_INBOX, inbox)
            self._json(201, evidence)
            return

        if path == "/api/postman/run":
            body = self._body_json()
            if body is None:
                return
            self._json(200, _postman_run(body))
            return

        if path == "/api/reliability/simulate-load":
            body = self._body_json()
            if body is None:
                return
            count = min(int(body.get("requests", 6)), 20)
            results = []
            for _ in range(count):
                results.append(load_balanced_response())
            self._json(200, {"requests": count, "results": results, "teachingPoint": "Use repeated calls to observe distribution and latency differences."})
            return

        if path == "/api/project/events":
            body = self._body_json()
            if body is None:
                return
            event = {"id": int(time.time() * 1000), "publishedAt": now_iso(), **body}
            with LOCK:
                messages = read_json(MESSAGES)
                messages.append({"topic": "project/events", "payload": event, "publishedAt": now_iso()})
                write_json(MESSAGES, messages)
            self._json(201, event)
            return

        if path == "/api/automation/inbox":
            body = self._body_json()
            if body is None:
                return
            event = {"id": int(time.time() * 1000), "receivedAt": now_iso(), "source": "n8n-or-postman", "payload": body}
            with LOCK:
                inbox = read_json(AUTOMATION_INBOX)
                inbox.append(event)
                write_json(AUTOMATION_INBOX, inbox)
            self._json(201, event)
            return

        if path == "/api/automation/workflow-run":
            body = self._body_json()
            if body is None:
                return
            result = _automation_run(body)
            with LOCK:
                inbox = read_json(AUTOMATION_INBOX)
                inbox.append({"id": int(time.time() * 1000), "receivedAt": now_iso(), "source": "workflow-run-simulator", "payload": result})
                write_json(AUTOMATION_INBOX, inbox)
            self._json(201, result)
            return

        self._json(404, {"error": "Route not found", "path": path})

    def do_PUT(self):
        product_id = self._product_id(urlparse(self.path).path)
        if product_id is None:
            self._json(404, {"error": "Use PUT /api/products/{id}"})
            return
        body = self._body_json()
        if body is None:
            return
        missing = [field for field in ["name", "category", "price", "stock"] if field not in body]
        if missing:
            self._json(400, {"error": "PUT requires full resource representation", "missing": missing})
            return
        with LOCK:
            products = read_json(PRODUCTS)
            for index, product in enumerate(products):
                if product["id"] == product_id:
                    replacement = {
                        "id": product_id,
                        "name": body["name"],
                        "category": body["category"],
                        "price": body["price"],
                        "stock": body["stock"],
                        "updatedAt": now_iso(),
                    }
                    products[index] = replacement
                    write_json(PRODUCTS, products)
                    self._json(200, replacement)
                    return
        self._json(404, {"error": "Product not found", "id": product_id})

    def do_PATCH(self):
        product_id = self._product_id(urlparse(self.path).path)
        if product_id is None:
            self._json(404, {"error": "Use PATCH /api/products/{id}"})
            return
        body = self._body_json()
        if body is None:
            return
        allowed = {"name", "category", "price", "stock"}
        invalid = [field for field in body if field not in allowed]
        if invalid:
            self._json(400, {"error": "Invalid fields", "invalid": invalid, "allowed": sorted(allowed)})
            return
        with LOCK:
            products = read_json(PRODUCTS)
            for product in products:
                if product["id"] == product_id:
                    product.update(body)
                    product["updatedAt"] = now_iso()
                    write_json(PRODUCTS, products)
                    self._json(200, product)
                    return
        self._json(404, {"error": "Product not found", "id": product_id})

    def do_DELETE(self):
        product_id = self._product_id(urlparse(self.path).path)
        if product_id is None:
            self._json(404, {"error": "Use DELETE /api/products/{id}"})
            return
        with LOCK:
            products = read_json(PRODUCTS)
            remaining = [product for product in products if product["id"] != product_id]
            if len(remaining) == len(products):
                self._json(404, {"error": "Product not found", "id": product_id})
                return
            write_json(PRODUCTS, remaining)
        self._no_content()

    def _websocket_echo(self):
        key = self.headers.get("Sec-WebSocket-Key")
        if not key:
            self._json(400, {"error": "Missing Sec-WebSocket-Key"})
            return
        accept = base64.b64encode(hashlib.sha1((key + WS_GUID).encode("ascii")).digest()).decode("ascii")
        self.send_response(101, "Switching Protocols")
        self.send_header("Upgrade", "websocket")
        self.send_header("Connection", "Upgrade")
        self.send_header("Sec-WebSocket-Accept", accept)
        self.end_headers()

        while True:
            frame = self._read_ws_frame()
            if frame is None:
                break
            opcode, payload = frame
            if opcode == 0x8:
                self._write_ws_frame("", opcode=0x8)
                break
            if opcode == 0x1:
                message = payload.decode("utf-8", errors="replace")
                query = parse_qs(urlparse(self.path).query)
                channel = query.get("channel", ["dashboard"])[0]
                try:
                    parsed_message = json.loads(message)
                except json.JSONDecodeError:
                    parsed_message = {"text": message}
                event = {
                    "id": int(time.time() * 1000),
                    "channel": channel,
                    "event": parsed_message.get("event", "websocket.message"),
                    "payload": parsed_message,
                    "publishedAt": now_iso(),
                    "transport": "websocket",
                }
                with LOCK:
                    events = read_json(REALTIME_EVENTS)
                    events.append(event)
                    write_json(REALTIME_EVENTS, events)
                response = json.dumps({"type": "echo", "receivedAt": now_iso(), "channel": channel, "message": message})
                self._write_ws_frame(response)

    def _read_ws_frame(self):
        header = self.rfile.read(2)
        if len(header) < 2:
            return None
        first, second = header
        opcode = first & 0x0F
        masked = second & 0x80
        length = second & 0x7F
        if length == 126:
            length = struct.unpack("!H", self.rfile.read(2))[0]
        elif length == 127:
            length = struct.unpack("!Q", self.rfile.read(8))[0]
        mask = self.rfile.read(4) if masked else b"\x00\x00\x00\x00"
        payload = bytearray(self.rfile.read(length))
        if masked:
            for index in range(length):
                payload[index] ^= mask[index % 4]
        return opcode, bytes(payload)

    def _write_ws_frame(self, message, opcode=0x1):
        payload = message.encode("utf-8") if isinstance(message, str) else message
        header = bytearray([0x80 | opcode])
        length = len(payload)
        if length < 126:
            header.append(length)
        elif length < 65536:
            header.extend([126])
            header.extend(struct.pack("!H", length))
        else:
            header.extend([127])
            header.extend(struct.pack("!Q", length))
        self.wfile.write(bytes(header) + payload)
        self.wfile.flush()


def _sample_records():
    return [
        {"id": 1, "sensor": "temperature", "value": 27.5, "unit": "celsius"},
        {"id": 2, "sensor": "humidity", "value": 61, "unit": "percent"},
        {"id": 3, "sensor": "latency", "value": 118, "unit": "ms"},
    ]


def _orders():
    return [
        {"orderId": "ORD-2026-001", "customer": "CakraMart", "amount": 450000, "status": "paid"},
        {"orderId": "ORD-2026-002", "customer": "Nusantara Data", "amount": 875000, "status": "processing"},
    ]


def _protocol_case():
    return {
        "scenario": "Retail analytics platform membutuhkan API ingestion, telemetry sensor, realtime notification, dan inference service.",
        "options": [
            {"protocol": "REST", "bestFor": "public API ingestion and CRUD", "tradeoff": "request-response, not real-time by default"},
            {"protocol": "WebSocket", "bestFor": "dashboard notification and bidirectional event", "tradeoff": "persistent connection management"},
            {"protocol": "MQTT", "bestFor": "IoT telemetry and pub/sub", "tradeoff": "needs broker and topic governance"},
            {"protocol": "gRPC", "bestFor": "internal service-to-service contract", "tradeoff": "less beginner-friendly for browser public API"},
        ],
        "discussionQuestion": "Protocol mana yang dipilih untuk tiap komponen dan evidence apa yang harus dikumpulkan?",
    }


def _proto_contract():
    return """syntax = "proto3";

package demo.inference;

service InferenceService {
  rpc Predict (PredictionRequest) returns (PredictionReply);
}

message PredictionRequest {
  string customer_id = 1;
  double avg_order_value = 2;
  int32 monthly_orders = 3;
}

message PredictionReply {
  string customer_id = 1;
  double score = 2;
  string label = 3;
}
"""


def _telemetry_proto_schema():
    return """syntax = "proto3";

package demo.telemetry;

message TelemetryRecord {
  int32 id = 1;
  string sensor = 2;
  double value = 3;
  string unit = 4;
  int64 captured_at_unix_ms = 5;
}

message TelemetryBatch {
  repeated TelemetryRecord records = 1;
}
"""


def _grpc_services():
    return {
        "services": [
            {
                "name": "demo.inference.InferenceService",
                "methods": [
                    {"name": "Predict", "type": "unary", "request": "PredictionRequest", "response": "PredictionReply"},
                    {"name": "BatchPredict", "type": "unary", "request": "BatchPredictionRequest", "response": "BatchPredictionReply"},
                    {"name": "HealthCheck", "type": "unary", "request": "HealthCheckRequest", "response": "HealthCheckReply"},
                ],
            }
        ],
        "teachingPoint": "gRPC exposes service methods with schema-defined request and response messages.",
    }


def _grpc_call(body):
    method = body.get("method", "Predict")
    payload = body.get("payload", {})
    if method == "HealthCheck":
        return {"method": method, "status": "SERVING", "protocolConcept": "unary RPC"}
    if method == "BatchPredict":
        items = payload.get("items", [])
        predictions = []
        for index, item in enumerate(items):
            features = item.get("features", {})
            score = min(float(features.get("monthlyOrders", 0)) / 10, 1.0)
            predictions.append({"index": index, "customerId": item.get("customerId"), "score": round(score, 3)})
        return {"method": method, "count": len(predictions), "predictions": predictions}
    features = payload.get("features", payload)
    score = 0.0
    score += min(float(features.get("avgOrderValue", 0)) / 500000, 1.0) * 0.55
    score += min(float(features.get("monthlyOrders", 0)) / 10, 1.0) * 0.45
    return {
        "method": method,
        "customerId": payload.get("customerId", body.get("customerId")),
        "score": round(score, 3),
        "label": "high_value" if score >= 0.6 else "standard",
        "protocolConcept": "This endpoint simulates a gRPC method call using JSON for classroom visibility.",
    }


def _encoding_convert(body):
    records = body.get("records") or _sample_records()
    target = body.get("to", "json").lower()
    if target == "json":
        encoded = json.dumps({"records": records}, indent=2)
        mime = "application/json"
    elif target == "xml":
        encoded_records = "".join(
            f"<record><id>{r.get('id')}</id><sensor>{r.get('sensor')}</sensor><value>{r.get('value')}</value><unit>{r.get('unit')}</unit></record>"
            for r in records
        )
        encoded = f'<?xml version="1.0" encoding="UTF-8"?><telemetry>{encoded_records}</telemetry>'
        mime = "application/xml"
    elif target == "csv":
        encoded = "id,sensor,value,unit\n" + "\n".join(
            f"{r.get('id')},{r.get('sensor')},{r.get('value')},{r.get('unit')}" for r in records
        )
        mime = "text/csv"
    elif target == "protobuf":
        encoded = base64.b64encode(json.dumps(records).encode("utf-8")).decode("ascii")
        mime = "application/x-protobuf-demo-base64"
    else:
        return {"error": "Unsupported target format", "supported": ["json", "xml", "csv", "protobuf"]}
    return {
        "target": target,
        "mime": mime,
        "byteLength": len(encoded.encode("utf-8")),
        "encoded": encoded,
        "note": "Protobuf output is base64 demo encoding for classroom comparison, not generated binary from protoc.",
    }


def _openapi_spec():
    return {
        "openapi": "3.0.3",
        "info": {
            "title": "Communication Protocols Demo API",
            "version": "1.0.0",
            "description": "Teaching API for Postman documentation, Newman-style testing, reliability, microservices, observability, and n8n automation labs.",
        },
        "servers": [{"url": "http://localhost:8088"}],
        "paths": {
            "/api/realtime/events": {"get": {"summary": "Read realtime events by channel"}, "post": {"summary": "Publish realtime event"}},
            "/api/products": {"get": {"summary": "List products"}, "post": {"summary": "Create product"}},
            "/api/mqtt/messages": {"get": {"summary": "Read MQTT-style messages by topic or filter"}},
            "/api/mqtt/publish": {"post": {"summary": "Publish MQTT-style telemetry with clientId, QoS, retained flag, topic, and payload"}},
            "/api/grpc/services": {"get": {"summary": "List gRPC-style services and methods"}},
            "/api/grpc/call": {"post": {"summary": "Simulate dynamic gRPC method call"}},
            "/api/encoding/convert": {"post": {"summary": "Convert records to JSON, XML, CSV, or Protobuf demo encoding"}},
            "/api/troubleshooting/test": {"post": {"summary": "Create controlled status code and delay scenario"}},
            "/api/reliability/rate-limited": {"get": {"summary": "Demonstrate 429 rate limiting"}},
            "/api/reliability/load-balanced": {"get": {"summary": "Demonstrate backend distribution"}},
            "/api/reliability/simulate-load": {"post": {"summary": "Simulate multiple load-balanced requests"}},
            "/api/microservices/order-flow": {"get": {"summary": "Show microservices communication pattern"}},
            "/api/microservices/orders": {"post": {"summary": "Simulate order flow with optional failure point"}},
            "/api/observability/metrics": {"get": {"summary": "Show request metrics"}},
            "/api/observability/custom-log": {"post": {"summary": "Create a custom log event"}},
            "/api/automation/inbox": {"get": {"summary": "Read automation inbox"}, "post": {"summary": "Receive n8n workflow output"}},
            "/api/automation/workflow-run": {"post": {"summary": "Simulate n8n workflow execution"}},
        },
        "teachingUse": "Pertemuan 9: document endpoints, define environment variables, add tests, and export collection evidence.",
    }


def _postman_run_summary():
    return {
        "meeting": 9,
        "topic": "API Design & Documentation using Postman and Newman/Postman CLI",
        "postmanCollection": "postman/Communication_Protocols_Demo_App.postman_collection.json",
        "environmentVariable": {"base_url": "http://localhost:8088"},
        "suggestedTests": [
            "Status code is expected",
            "Response has required field",
            "Latency is below a selected classroom threshold",
            "Mutation is verified by a read-back request",
        ],
        "newmanCommandExamples": [
            "newman run postman/Communication_Protocols_Demo_App.postman_collection.json --env-var base_url=http://localhost:8088",
            "newman run postman/Communication_Protocols_Demo_App.postman_collection.json --folder \"P9 API Documentation and Newman\" --env-var base_url=http://localhost:8088"
        ],
        "note": "Newman requires Node.js/npm installation. If unavailable, use Postman Collection Runner and export screenshots as fallback.",
    }


def _postman_run(body):
    folder = body.get("folder", "P9 API Documentation and Newman")
    iterations = min(int(body.get("iterations", 1)), 10)
    tests = [
        {"name": "status code is expected", "passed": True},
        {"name": "response time below classroom threshold", "passed": True},
        {"name": "required field exists", "passed": True},
    ]
    return {
        "runner": "postman-runner-simulator",
        "folder": folder,
        "iterations": iterations,
        "totalRequests": iterations * 3,
        "tests": tests,
        "summary": {"passed": len(tests) * iterations, "failed": 0},
        "teachingPoint": "Use this as a local stand-in if Newman is unavailable; real Newman should be run from CLI when installed.",
    }


def _microservice_order_flow(body=None):
    order_id = (body or {}).get("orderId", "ORD-DEMO-001")
    amount = (body or {}).get("amount", 450000)
    fail_at = (body or {}).get("failAt")
    steps = [
        {"service": "api-gateway", "protocol": "HTTP/REST", "latencyMs": 24, "status": 200},
        {"service": "order-service", "protocol": "gRPC internal call", "latencyMs": 41, "status": "OK"},
        {"service": "inventory-service", "protocol": "HTTP/REST", "latencyMs": 38, "status": 200},
        {"service": "payment-service", "protocol": "HTTP/REST", "latencyMs": 76, "status": 200},
        {"service": "notification-service", "protocol": "WebSocket event", "latencyMs": 18, "status": "sent"},
    ]
    if fail_at:
        for step in steps:
            if step["service"] == fail_at:
                step["status"] = "FAILED"
                step["error"] = f"Simulated failure at {fail_at}"
    return {
        "traceId": f"trace-{order_id.lower()}",
        "pattern": "API gateway -> order service -> inventory service -> payment service -> notification service",
        "request": {"orderId": order_id, "amount": amount},
        "steps": steps,
        "teachingPoint": "Microservices communication needs clear contracts, timeouts, retries, and observability across service boundaries.",
    }


def _metrics():
    status_counts = {}
    path_counts = {}
    for entry in REQUEST_LOGS:
        status_counts[str(entry["status"])] = status_counts.get(str(entry["status"]), 0) + 1
        path_counts[entry["path"]] = path_counts.get(entry["path"], 0) + 1
    return {
        "requestCount": len(REQUEST_LOGS),
        "statusCounts": status_counts,
        "topPaths": sorted(path_counts.items(), key=lambda item: item[1], reverse=True)[:8],
        "rateLimitClients": {client: len(hits) for client, hits in RATE_HITS.items()},
        "teachingPoint": "Metrics aggregate behavior; logs explain individual events; traces connect events across services.",
    }


def _trace(trace_id):
    return {
        "traceId": trace_id,
        "spans": [
            {"span": "gateway.receive", "durationMs": 12, "status": "OK"},
            {"span": "order.validate", "durationMs": 20, "status": "OK"},
            {"span": "inventory.reserve", "durationMs": 43, "status": "OK"},
            {"span": "payment.authorize", "durationMs": 88, "status": "OK"},
            {"span": "notification.publish", "durationMs": 16, "status": "OK"},
        ],
        "teachingPoint": "Trace shows one request path across multiple components.",
    }


def _n8n_workflow_spec():
    return {
        "meeting": "Pertemuan 13-15",
        "topic": "Automation using n8n for protocol integration and project phase",
        "recommendedWorkflow": [
            "Webhook Trigger receives JSON payload",
            "Set node normalizes fields: protocol, event, evidence",
            "HTTP Request node POSTs to http://localhost:8088/api/automation/inbox",
            "Respond to Webhook returns confirmation",
        ],
        "dockerNote": "If n8n runs inside Docker, replace localhost with host.docker.internal when calling the demo app.",
        "sampleWebhookPayload": {
            "protocol": "MQTT+REST",
            "event": "telemetry.ingested",
            "deviceId": "sensor-01",
            "evidence": "postman-screenshot",
        },
        "fallback": "If n8n setup fails, simulate the automation output by POSTing directly to /api/automation/inbox from Postman.",
    }


def _automation_run(body):
    workflow = body.get("workflow", "telemetry-to-inbox")
    source_event = body.get("event", "telemetry.workflow.completed")
    return {
        "workflow": workflow,
        "runId": f"run-{int(time.time() * 1000)}",
        "status": "success",
        "steps": [
            {"node": "Webhook Trigger", "status": "success", "output": {"event": source_event}},
            {"node": "Set/Edit Fields", "status": "success", "output": {"normalized": True}},
            {"node": "HTTP Request", "status": "success", "output": {"target": "/api/automation/inbox"}},
            {"node": "Respond to Webhook", "status": "success", "output": {"status": "accepted"}},
        ],
        "teachingPoint": "Automation evidence should show trigger input, transformation, HTTP call, and final response.",
    }


def _project_summary():
    messages = read_json(MESSAGES)
    return {
        "minimumRequirements": [
            "Use at least two protocol concepts",
            "Provide Postman/curl evidence",
            "Explain status code or message flow",
            "Include troubleshooting notes",
            "Include automation or integration evidence when using n8n",
        ],
        "currentEvidenceCount": len(messages),
        "suggestedProject": "MQTT telemetry + WebSocket notification + n8n automation + Postman/Newman evidence",
    }


if __name__ == "__main__":
    DATA.mkdir(exist_ok=True)
    if not PRODUCTS.exists():
        shutil.copyfile(PRODUCTS_SEED, PRODUCTS)
    if not MESSAGES.exists():
        write_json(MESSAGES, [])
    if not WEBHOOK_INBOX.exists():
        write_json(WEBHOOK_INBOX, [])
    if not AUTOMATION_INBOX.exists():
        write_json(AUTOMATION_INBOX, [])
    if not REALTIME_EVENTS.exists():
        write_json(REALTIME_EVENTS, [])

    server = ThreadingHTTPServer((HOST, PORT), DemoHandler)
    print(f"Communication Protocols Demo App running at http://{HOST}:{PORT}")
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.server_close()
